*****************************************************************************
** ChibiOS/RT port for ARM-Cortex-M4 MK20DX128.                            **
*****************************************************************************

** TARGET **

The demo runs on a PJRC Teensy 3 board.

** The Demo **

The demo shows how to blink the LED on pin 13 of the board.

** Build Procedure **

The demo has been tested by using the free ARM-none GCC toolchain. Just
modify the TRGT line in the makefile in order to use different GCC
toolchains.
