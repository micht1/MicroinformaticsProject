*****************************************************************************
** ChibiOS/RT port for ARM-Cortex-M4 MCHCK K20 .                           **
*****************************************************************************

** TARGET **

The demo runs on an MKHCK K20 board. It use the PIT to implement the ChibiOS
GPT functionality.
